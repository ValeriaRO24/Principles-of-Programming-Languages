{-|
Module: A2
Description: Assignment 2
Copyright: (c) University of Toronto Mississagua
               CSC324 Principles of Programming Languages, Fall 2023
-}
-- This lists what this module exports. Don't change this!
module A2
  (
    run,
    eval
  )
where

-- You *may not* add imports from Data.Map, or any other imports
import A2Types(Expr(..), Value(..), Env)
import qualified Data.Map (lookup, insert, empty)


-- | Runs a Godel expression by calling `eval` with the empty environment
run :: Expr -> Value
run e = eval Data.Map.empty e


-- | An interpreter for the Godel language.
eval :: Env -> Expr -> Value
eval env (Literal v) = v -- todo


eval env (Plus a b)  = case ((eval env a), (eval env b)) of
    (Num x, Num y) -> Num(x + y) -- todo
    (Error x, y) -> Error x
    (x, Error y) -> Error y
    _              -> Error "Plus" -- todo

eval env (Times a b)  = case ((eval env a), (eval env b)) of
  (Num x, Num y) -> Num(x * y)
  (Error x, y) -> Error x
  (x, Error y) -> Error y
  _              -> Error "Times"


eval env (Equal a b)  = case ((eval env a), (eval env b)) of
    
    (Error x, y) -> Error x
    (x, Error y) -> Error y
    (x, y) -> if x == y then T else F
   
eval env (If a b c)  = case eval env a of
      Error a -> Error a
      T -> eval env b
      _ -> eval env c

  
  



    -- what other patterns are missing above (if any)?


eval env (Var name)  = case (Data.Map.lookup name env) of
    Just a  -> a -- "a" is of type Value 
    Nothing -> Error "Var" -- "name" is not found in "env"




eval env _           = undefined -- todo what other cases are missing?


-- | Helper function to obtain a list of unique elements in a list
-- Example:
--   ghci> unique [1, 2, 3, 4]
--   [1,2,3,4]
--   ghci> unique [1, 2, 3, 4, 4]
--   [1,2,3,4]
unique :: (Eq a) => [a] -> [a]
unique [] = []
unique (x:xs)
  | elem x xs = unique xs
  | otherwise = x : unique xs



